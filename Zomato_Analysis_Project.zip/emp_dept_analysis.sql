create database emp_dept_analysis;
use emp_dept_analysis;
create table Dept(
deptno integer primary key,
dname varchar (30),
loc varchar(50));
desc dept;
insert into Dept values(10,"OPERATIONS","BOSTON"),(20,"RESEARCH","DALLAS"),(30,"SALES","CHICAGO"),(40,"ACCOUNTING","NEW YORK");
select * from dept;
create table employee(
empno integer primary key  not null unique,
ename varchar(30),
job varchar(30) default "CLERK",
mgr integer,
hiredate date,
sal decimal(18,2) check (sal>=0),
comm decimal(18,2),
deptno integer,
foreign key(deptno)  references dept(deptno)
on delete cascade 
on update cascade);
desc employee;
insert into employee (empno,ename,mgr,hiredate,sal,deptno) values (7369,"SMITH",7902,"1890-12-17",800,20);
insert into employee (empno,ename,job,mgr,hiredate,sal,comm,deptno) values(7499,"ALLEN","SALESMAN",7698,"1981-02-20",1600,300,30);
insert into employee (empno,ename,job,mgr,hiredate,sal,comm,deptno) values(7521,"WARD","SALESMAN",7698,"1981-02-22",1250,500,30);
insert into employee (empno,ename,job,mgr,hiredate,sal,deptno) values(7566,"JONES","MANAGER",7839,"1981-04-02",2975,20);
insert into employee (empno,ename,job,mgr,hiredate,sal,comm,deptno) values(7654,"MARTIN","SALESMAN",7698,"1981-09-28",1250,1400,30);
insert into employee (empno,ename,job,mgr,hiredate,sal,deptno) values(7698,"BLAKE","MANAGER",7839,"1981-05-01",2850,30);
insert into employee (empno,ename,job,mgr,hiredate,sal,deptno) values(7782,"CLARK","MANAGER",7839,"1981-06-09",2450,10);
insert into employee (empno,ename,job,mgr,hiredate,sal,deptno) values(7788,"SCOTT","ANALYST",7566,"1987-04-19",3000,20);
insert into employee (empno,ename,job,hiredate,sal,deptno) values(7839,"KING","PRESIDENT","1981-11-17",5000,10);
insert into employee (empno,ename,job,mgr,hiredate,sal,comm,deptno) values(7844,"TURNER","SALESMAN",7698,"1981-09-08",1500,0,30);
insert into employee (empno,ename,mgr,hiredate,sal,deptno) values(7876,"ADAMS",7788,"1987-05-23",1100,20);
insert into employee (empno,ename,mgr,hiredate,sal,deptno) values(7900,"JAMES",7698,"1981-12-03",950,30);
insert into employee (empno,ename,job,mgr,hiredate,sal,deptno) values(7902,"FORD","ANALYST",7566,"1981-12-03",3000,20);
insert into employee (empno,ename,mgr,hiredate,sal,deptno) values(7934,"MILLER",7782,"1982-01-23",1300,10);
select * from employee;
-- 3.	List the Names and salary of the employee whose salary is greater than 1000 --
select ename,sal from employee where sal>1000;

-- 4.	List the details of the employees who have joined before end of September 81 --
select * from employee where hiredate < "1981-09-30";

-- 5.	List Employee Names having I as second character --
select * from  employee where ename like '_i%';


-- 6.List Employee Name, Salary, Allowances (40% of Sal), P.F. (10 % of Sal) and Net Salary. Also assign the alias name for the columns
select ename,sal,sal*0.4 as Allowances,sal*0.1 as PF,sal+(sal*0.4)+(sal*0.1) as Net_Salary from employee;

--  7.List Employee Names with designations who does not report to anybody (doubt) --
select ename,job from employee where mgr=null;

-- 8.	List Empno, Ename and Salary in the ascending order of salary --

